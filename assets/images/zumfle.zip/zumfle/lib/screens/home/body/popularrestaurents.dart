

import 'package:flutter/cupertino.dart';
import 'package:zumfle/products/productlist.dart';

class PopularRestaurent extends StatelessWidget {
  const PopularRestaurent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const popularrestaurants = PopularRestaurants.Popularrestaurants ;
    return ListView.builder(
           scrollDirection: Axis.vertical,
           shrinkWrap: true,
           itemCount: popularrestaurants.length,
           itemBuilder: (BuildContext context, int index) {
             return Container(
               height: 100,
               width: 150,
               decoration: BoxDecoration(
                 borderRadius: BorderRadius.circular(10),
                 image: DecorationImage(
                     image: AssetImage(popularrestaurants[index].image)
                 ),
               ),
             );
           }
        );

  }
}
