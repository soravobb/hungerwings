

import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zumfle/constants/constants.dart';

import '../../widgets/widgets.dart';
import 'body/cuisineslist.dart';
import 'body/popularrestaurents.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: MediaQuery.of(context).size.height *0.05,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              children: [
                Row(children: [
                  Text("Welcome Hunger!",
                    style: FontConstant.normaltext.copyWith(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,),
                  ),
                  Spacer(flex: 5),
                  Icon(Icons.shopping_cart_rounded, size: 25.0),],
                ),
              ],
            ),
          ),
          ListView(
            shrinkWrap: true,
             physics: const ScrollPhysics(),
             children: [
               Column(
                 children: [
                   Padding(
                     padding: const EdgeInsets.symmetric(horizontal: 20.0),
                     child: Row(
                       children: [
                         Column(crossAxisAlignment: CrossAxisAlignment.start,
                           children: [
                             Text("Delivering to",
                               style: FontConstant.lightText.copyWith(
                                   fontSize: 12,),
                             ),
                             Row(
                               children: [
                                 Text("Current Location",
                                   style: FontConstant.lightText.copyWith(
                                     fontSize: 15,
                                   fontWeight: FontWeight.bold,
                                   color: Colors.grey[700]),
                                 ),
                                 SizedBox(width: 15,),
                                 Icon(Icons.keyboard_arrow_down_rounded, size: 20.0,
                                 color: Color(0xff911a1c),),
                               ],
                             ),
                           ],
                         )
                       ],
                     ),
                   ),
                 ],
               ),
               SizedBox(height: MediaQuery.of(context).size.height *0.03,),
               Padding(padding: EdgeInsets.symmetric(horizontal: 20.0),child:searchfield(context, "Search food"),),
               Cuisines(),
               SizedBox(height: MediaQuery.of(context).size.height *0.03,),
               Padding(
                 padding: EdgeInsets.symmetric(horizontal: 20.0),
                 child: Row(children: [
                   Text("Popular Restaurents",
                     style: FontConstant.normaltext.copyWith(
                       fontSize: 20,
                       fontWeight: FontWeight.w900,
                       color: Colors.black,),
                   ),
                   Spacer(flex: 5),
                   Text(
                     "View all",
                     style: FontConstant.normaltext.copyWith(
                         fontWeight: FontWeight.bold,
                         fontSize: 12.0,
                         color: Color(0xff911a1c)
                     ),
                   ),
                 ],
                 ),
               ),
               PopularRestaurent(),

             ],
           ),

        ],
      ),
    );
  }
}
