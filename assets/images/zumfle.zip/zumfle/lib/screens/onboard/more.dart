import 'package:flutter/material.dart';

import '../../constants/constants.dart';

class more extends StatelessWidget {
  const more({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Text('More',style:FontConstant.normaltext.copyWith(fontSize: 25,fontWeight: FontWeight.bold,color:ThemeColor.primaryRed)),
      actions: [
        GestureDetector(
          onTap: () {},
          child: Icon(
            Icons.shopping_cart_rounded,
            size: 25.0,
          ),
        )
      ],
      ),
      body: ListView(
        padding: EdgeInsets.all(20.0),
        children: <Widget>[
          GestureDetector(
            onTap: (){},

            child: Container(
              height: 100,
              width: 300,
              color: Colors.grey[100],

              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.all(10.0),
                    height: 70.0,
                    width: 70.0,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(
                            'assets/images/002income.png'),
                        scale: 1.25,

                        // fit: BoxFit.fitHeight,
                      ),
                      shape: BoxShape.circle,
                      color: Colors.grey[400],
                    ),
                  ),
                  Container(
                    child: Text('Payment Details',style: FontConstant.normaltext.copyWith(fontSize:20,fontWeight: FontWeight.bold,color:Colors.black )),
                  )
                ],
              ),

            ),
          ),
          SizedBox(height: 20),
          GestureDetector(
            onTap: (){},
            child: Container(
              height: 100,
              width: 350,
              color: Colors.grey[100],

              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.all(10.0),
                    height: 70.0,
                    width: 70.0,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(
                            'assets/images/shoppibag.png'),
                        scale: 1.25,
                      ),
                      shape: BoxShape.circle,
                      color: Colors.grey[400],
                    ),
                  ),
                  Container(
                    child: Text('My Orders',style: FontConstant.normaltext.copyWith(fontSize:20,fontWeight: FontWeight.bold,color:Colors.black )),
                  )
                ],
              ),

            ),
          ),
          SizedBox(height: 20,),
          GestureDetector(
            onTap: (){},
            child: Container(
              height: 100,
              width: 350,
              color: Colors.grey[100],

              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.all(10.0),
                    height: 70.0,
                    width: 70.0,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(
                            'assets/images/Group 8081.png'),
                        scale: 1.25,

                        // fit: BoxFit.fitHeight,
                      ),
                      shape: BoxShape.circle,
                      color: Colors.grey[400],
                    ),
                  ),
                  Container(
                    child: Text('Notifications',style: FontConstant.normaltext.copyWith(fontSize:20,fontWeight: FontWeight.bold,color:Colors.black )),
                  )
                ],
              ),

            ),
          ),
          SizedBox(height: 20,),
          GestureDetector(
            onTap: (){},
            child: Container(
              height: 100,
              width: 350,
              color: Colors.grey[100],

              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.all(10.0),
                    height: 70.0,
                    width: 70.0,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(
                            'assets/images/Path 10157.png'),
                        scale: 1.25,

                        // fit: BoxFit.fitHeight,
                      ),
                      shape: BoxShape.circle,
                      color: Colors.grey[400],
                    ),
                  ),
                  Container(
                    child: Text('About Us',style: FontConstant.normaltext.copyWith(fontSize:20,fontWeight: FontWeight.bold,color:Colors.black )),
                  )
                ],
              ),

            ),
          ),


        ],

      )
    );
  }
}
