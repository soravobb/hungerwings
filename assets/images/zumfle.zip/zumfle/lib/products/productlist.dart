class Cuisine {
  const Cuisine({
    required this.image,
    required this.title,

  });

  final String image;
  final String title;


  static const cuisines = [
    Cuisine(
        image: "assets/images/tea2.png",
        title: "Offers"),
    Cuisine(
        image: "assets/images/tea2.png",
        title: "Sri Lankan"),
    Cuisine(
        image: "assets/images/tea2.png",
        title: "Italian"),
    Cuisine(
        image: "assets/images/tea2.png",
        title: "indian"),
  ];
}

class PopularRestaurants {
  const PopularRestaurants({
    required this.image,
    required this.title,
    required this.rating,
    required this.description,
    required this.name,

  });

  final String image;
  final String title;
  final String rating;
  final String description;
  final String name;


  static const Popularrestaurants = [
    PopularRestaurants(
        image: "assets/images/pizza.png",
        title: "Minute by tuk tuk",
        rating: "4.9",
        description: "(124 ratings) Cafe",
        name: "Western Food"
    ),
    PopularRestaurants(
        image: "assets/images/pizza.png",
        title: "Minute by tuk tuk",
        rating: "4.9",
        description: "(124 ratings) Cafe",
        name: "Western Food"
    ),
    PopularRestaurants(
        image: "assets/images/pizza.png",
        title: "Minute by tuk tuk",
        rating: "4.9",
        description: "(124 ratings) Cafe",
        name: "Western Food"
    ),
  ];
}